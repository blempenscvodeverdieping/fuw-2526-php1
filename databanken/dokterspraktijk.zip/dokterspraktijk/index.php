<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
    <h1>Dokterspraktijk</h1>

    <ul>
        <li><a href="gemeentes.php">Gemeentes</a></li>
        <li><a href="aandoeningen.php">Aandoeningen</a></li>
        <li><a href="patienten.php">Patienten</a></li>
        <li><a href="consultaties.php">Consultaties</a></li>
    </ul>
</body>
</html>
